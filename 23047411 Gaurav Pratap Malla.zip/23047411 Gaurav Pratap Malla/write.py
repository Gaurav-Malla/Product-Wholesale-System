import datetime
import os

def update_product_file(filename, products):
    """
    Update the product file with the current product data.
    """
    try:
        with open(filename, 'w') as file:
            for product in products:
                line = f"{product['name']}, {product['brand']}, {product['quantity']}, {product['cost_price']}, {product['origin']}\n"
                file.write(line)
        return True
    except Exception as e:
        print(f"Error updating product file: {e}")
        return False

def generate_sales_invoice(customer_name, items, total_amount):
    """
    Generate a sales invoice and save it to a file.
    """
    # Create invoices directory if it doesn't exist
    if not os.path.exists("invoices"):
        os.makedirs("invoices")
    
    # Generate unique filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"invoices/sale_{customer_name.replace(' ', '_')}_{timestamp}.txt"
    
    # Write invoice to file
    try:
        with open(filename, 'w') as file:
            # Write header
            file.write("="*60 + "\n")
            file.write(f"{'WECARE BEAUTY PRODUCTS':^60}\n")
            file.write(f"{'SALES INVOICE':^60}\n")
            file.write("="*60 + "\n\n")
            
            # Write customer info
            file.write(f"Customer: {customer_name}\n")
            file.write(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Write items
            file.write(f"{'PRODUCT':<20} {'BRAND':<15} {'QTY':<5} {'FREE':<5} {'PRICE':<10}\n")
            file.write("-"*60 + "\n")
            
            for item in items:
                file.write(f"{item['name']:<20} {item['brand']:<15} {item['quantity']:<5} {item['free_items']:<5} {item['price']:<10.2f}\n")
            
            # Write total
            file.write("\n" + "-"*60 + "\n")
            file.write(f"{'TOTAL AMOUNT:':<40} {total_amount:.2f}\n")
            file.write("="*60 + "\n\n")
            
            # Write footer
            file.write(f"{'Thank you for shopping with us!':^60}\n")
            file.write(f"{'*Buy 3 Get 1 Free offer applied':^60}\n")
        
        print(f"Invoice saved to {filename}")
        return filename
    except Exception as e:
        print(f"Error generating invoice: {e}")
        return None

def generate_purchase_invoice(supplier_name, items, total_cost):
    """
    Generate a purchase invoice and save it to a file.
    """
    # Create invoices directory if it doesn't exist
    if not os.path.exists("invoices"):
        os.makedirs("invoices")
    
    # Generate unique filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"invoices/purchase_{supplier_name.replace(' ', '_')}_{timestamp}.txt"
    
    # Write invoice to file
    try:
        with open(filename, 'w') as file:
            # Write header
            file.write("="*60 + "\n")
            file.write(f"{'WECARE BEAUTY PRODUCTS':^60}\n")
            file.write(f"{'PURCHASE INVOICE':^60}\n")
            file.write("="*60 + "\n\n")
            
            # Write supplier info
            file.write(f"Supplier: {supplier_name}\n")
            file.write(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Write items
            file.write(f"{'PRODUCT':<20} {'BRAND':<15} {'QTY':<5} {'COST':<10} {'AMOUNT':<10}\n")
            file.write("-"*60 + "\n")
            
            for item in items:
                file.write(f"{item['name']:<20} {item['brand']:<15} {item['quantity']:<5} {item['cost_price']:<10.2f} {item['amount']:<10.2f}\n")
            
            # Write total
            file.write("\n" + "-"*60 + "\n")
            file.write(f"{'TOTAL COST:':<40} {total_cost:.2f}\n")
            file.write("="*60 + "\n")
        
        print(f"Invoice saved to {filename}")
        return filename
    except Exception as e:
        print(f"Error generating invoice: {e}")
        return None
