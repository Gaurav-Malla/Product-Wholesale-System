def read_product_file(filename):
    """
    Read product data from a text file and return it as a list of dictionaries.
    """
    products = []
    try:
        with open(filename, 'r') as file:
            for line in file:
                # Strip whitespace and split by comma
                parts = [part.strip() for part in line.strip().split(',')]
                
                # Check if we have all 5 parts
                if len(parts) == 5:
                    # Convert numeric values to appropriate types
                    try:
                        quantity = int(parts[2])
                        cost_price = float(parts[3])
                        
                        # Create a dictionary for the product
                        product = {
                            "name": parts[0],
                            "brand": parts[1],
                            "quantity": quantity,
                            "cost_price": cost_price,
                            "selling_price": cost_price * 2,  # 200% markup
                            "origin": parts[4]
                        }
                        products.append(product)
                    except ValueError:
                        print(f"Error: Invalid numeric data in line: {line}")
                else:
                    print(f"Error: Invalid format in line: {line}")
        
        return products
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return []

def read_invoice(filename):
    """
    Read an invoice file and display its contents.
    """
    try:
        with open(filename, 'r') as file:
            content = file.read()
            print("\n" + "="*60)
            print("INVOICE CONTENT:")
            print(content)
            print("="*60 + "\n")
        return True
    except FileNotFoundError:
        print(f"Error: Invoice file '{filename}' not found.")
        return False
