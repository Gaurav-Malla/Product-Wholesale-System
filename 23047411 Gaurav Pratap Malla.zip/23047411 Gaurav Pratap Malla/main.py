from read import read_product_file, read_invoice
from operation import display_products, sell_products, purchase_products
import os

def main():
    """
    Main function to run the program.
    """
    print("\n" + "="*60)
    print(f"{'WECARE PRODUCT WHOLESALE SYSTEM':^60}")
    print("="*60 + "\n")
    
    # Create invoices directory if it doesn't exist
    if not os.path.exists("invoices"):
        os.makedirs("invoices")
    
    # Product file
    product_file = "products.txt"
    
    # Main program loop
    while True:
        # Read product data from file (read fresh data each time to ensure it's up to date)
        products = read_product_file(product_file)
        
        if not products:
            print("No products found. Please check the product file.")
            return
        
        print("\nMAIN MENU:")
        print("1. View Products")
        print("2. Sell Products")
        print("3. Purchase Products")
        print("4. View Invoice")
        print("5. Exit")
        
        # Get user choice
        choice = 0
        try:
            choice = int(input("Enter your choice (1-5): "))
            if choice < 1 or choice > 5:
                print("Invalid choice. Please enter a number between 1 and 5.")
                continue
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue
        
        # Process user choice
        if choice == 1:
            display_products(products)
        elif choice == 2:
            invoice_file = sell_products(products, product_file)
            if invoice_file:
                view_invoice = input("Do you want to view the invoice? (y/n): ").lower()
                if view_invoice == 'y':
                    read_invoice(invoice_file)
        elif choice == 3:
            invoice_file = purchase_products(products, product_file)
            if invoice_file:
                view_invoice = input("Do you want to view the invoice? (y/n): ").lower()
                if view_invoice == 'y':
                    read_invoice(invoice_file)
        elif choice == 4:
            # List all invoices
            if os.path.exists("invoices") and os.listdir("invoices"):
                print("\nAvailable Invoices:")
                invoices = os.listdir("invoices")
                for i, invoice in enumerate(invoices):
                    print(f"{i+1}. {invoice}")
                
                # Get invoice selection
                try:
                    idx = int(input("Enter invoice number to view (0 to cancel): "))
                    if idx == 0:
                        continue
                    if idx < 1 or idx > len(invoices):
                        print("Invalid invoice number.")
                        continue
                    
                    # View selected invoice
                    read_invoice(f"invoices/{invoices[idx-1]}")
                except ValueError:
                    print("Invalid input. Please enter a number.")
            else:
                print("No invoices found.")
        elif choice == 5:
            print("\nThank you for using WeCare Product Wholesale System. Goodbye!")
            break

if __name__ == "__main__":
    main()
