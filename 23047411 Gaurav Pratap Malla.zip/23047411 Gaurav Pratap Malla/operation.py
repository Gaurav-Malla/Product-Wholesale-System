from read import read_product_file
from write import update_product_file, generate_sales_invoice, generate_purchase_invoice

def display_products(products):
    """
    Display product information in a readable format.
    """
    if not products:
        print("No products to display.")
        return
    
    # Print header
    print("\n" + "="*90)
    print(f"{'INDEX':<6} {'PRODUCT NAME':<20} {'BRAND':<15} {'QUANTITY':<10} {'COST PRICE':<12} {'SELLING PRICE':<15} {'ORIGIN':<15}")
    print("-"*90)
    
    # Print each product
    for i, product in enumerate(products):
        print(f"{i+1:<6} {product['name']:<20} {product['brand']:<15} {product['quantity']:<10} {product['cost_price']:<12.2f} {product['selling_price']:<15.2f} {product['origin']:<15}")
    
    print("="*90 + "\n")

def get_valid_integer(prompt, min_value=None, max_value=None):
    """
    Get a valid integer input from the user.
    """
    while True:
        try:
            value = int(input(prompt))
            if min_value is not None and value < min_value:
                print(f"Error: Value must be at least {min_value}.")
                continue
            if max_value is not None and value > max_value:
                print(f"Error: Value must be at most {max_value}.")
                continue
            return value
        except ValueError:
            print("Error: Please enter a valid integer.")

def get_valid_float(prompt, min_value=None):
    """
    Get a valid float input from the user.
    """
    while True:
        try:
            value = float(input(prompt))
            if min_value is not None and value < min_value:
                print(f"Error: Value must be at least {min_value}.")
                continue
            return value
        except ValueError:
            print("Error: Please enter a valid number.")

def sell_products(products, product_file):
    """
    Process a sales transaction.
    """
    if not products:
        print("No products available for sale.")
        return products
    
    print("\n=== SELL PRODUCTS ===\n")
    
    # Display available products
    display_products(products)
    
    # Get customer information
    customer_name = input("Enter customer name: ")
    
    # Initialize transaction
    transaction_items = []
    total_amount = 0
    
    # Add products to transaction
    while True:
        # Get product selection
        product_idx = get_valid_integer("Enter product index (1-" + str(len(products)) + "): ", 1, len(products)) - 1
        selected_product = products[product_idx]
        
        # Check if product is in stock
        if selected_product['quantity'] <= 0:
            print(f"Error: {selected_product['name']} is out of stock.")
            continue
        
        # Get quantity
        max_quantity = selected_product['quantity']
        quantity = get_valid_integer(f"Enter quantity (1-{max_quantity}): ", 1, max_quantity)
        
        # Calculate free items (buy 3 get 1 free)
        free_items = quantity // 3
        total_items = quantity + free_items
        
        # Check if we have enough stock
        if total_items > selected_product['quantity']:
            print(f"Error: Not enough stock. Available: {selected_product['quantity']}, Required: {total_items}")
            continue
        
        # Calculate amount
        amount = quantity * selected_product['selling_price']
        total_amount += amount
        
        # Add to transaction items
        transaction_items.append({
            "name": selected_product['name'],
            "brand": selected_product['brand'],
            "quantity": quantity,
            "free_items": free_items,
            "price": amount
        })
        
        # Update product quantity
        selected_product['quantity'] -= total_items
        
        # Ask if user wants to add more products
        add_more = input("Add more products? (y/n): ").lower()
        if add_more != 'y':
            break
    
    # Generate invoice
    if transaction_items:
        invoice_file = generate_sales_invoice(customer_name, transaction_items, total_amount)
        
        # Update product file
        update_product_file(product_file, products)
        
        print(f"\nTransaction completed. Total amount: Rs. {total_amount:.2f}")
        print(f"Invoice generated for {customer_name}.")
        
        return invoice_file
    else:
        print("Transaction cancelled. No items added.")
        return None

def purchase_products(products, product_file):
    """
    Process a purchase transaction (restock).
    """
    print("\n=== PURCHASE PRODUCTS ===\n")
    
    # Display current products
    display_products(products)
    
    # Get supplier information
    supplier_name = input("Enter supplier name: ")
    
    # Initialize purchase
    purchase_items = []
    total_cost = 0
    
    # Add products to purchase
    while True:
        # Get product selection
        product_idx = get_valid_integer("Enter product index (1-" + str(len(products)) + "): ", 1, len(products)) - 1
        selected_product = products[product_idx]
        
        # Get quantity
        quantity = get_valid_integer("Enter quantity to purchase: ", 1)
        
        # Check if cost price has changed
        update_price = input("Has the cost price changed? (y/n): ").lower()
        
        cost_price = selected_product['cost_price']
        if update_price == 'y':
            cost_price = get_valid_float(f"Enter new cost price (current: {cost_price}): ", 0.01)
            # Update cost price and selling price
            selected_product['cost_price'] = cost_price
            selected_product['selling_price'] = cost_price * 2  # 200% markup
        
        # Calculate amount
        amount = quantity * cost_price
        total_cost += amount
        
        # Add to purchase items
        purchase_items.append({
            "name": selected_product['name'],
            "brand": selected_product['brand'],
            "quantity": quantity,
            "cost_price": cost_price,
            "amount": amount
        })
        
        # Update product quantity
        selected_product['quantity'] += quantity
        
        # Ask if user wants to add more products
        add_more = input("Add more products? (y/n): ").lower()
        if add_more != 'y':
            break
    
    # Generate invoice
    if purchase_items:
        invoice_file = generate_purchase_invoice(supplier_name, purchase_items, total_cost)
        
        # Update product file
        update_product_file(product_file, products)
        
        print(f"\nPurchase completed. Total cost: Rs. {total_cost:.2f}")
        print(f"Invoice generated for supplier {supplier_name}.")
        
        return invoice_file
    else:
        print("Purchase cancelled. No items added.")
        return None
